export const environment = {
  production: true,
  apiEndpointHeroes: 'http://crisfon6.com/api/v1/heroes',
};
