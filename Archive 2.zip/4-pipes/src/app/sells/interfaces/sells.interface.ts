export interface Hero {
  name: string;
  fly: boolean;
  color: Color;
}
export enum Color {
  red,
  black,
  blue,
  green,
}
